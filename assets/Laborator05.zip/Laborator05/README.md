# Laborator 5 — Refresh, paginare, progres

Două proiecte independente, fiecare fără dependențe externe (doar `react` + `react-native`).

```
Perechea1/   catalog paginat (dummyjson), pull-to-refresh, 3 tipuri de erori
Perechea2/   bară de progres determinată + cronometru
```

## Rulare în Snack
1. https://snack.expo.dev → Create a snack.
2. Creează folderele (`screens`, respectiv `components`) și fișierele.
3. Lipește conținutul; `App.js` este punctul de intrare.

## Rulare local (Expo)
Fiecare subfolder este un proiect complet (`package.json`, `index.js`, `app.json`).
```bash
cd Perechea1        # sau Perechea2
npm install
npx expo start
```

## Verificare rapidă
- Prima pagină: spinner ~1 s → „20 din N produse”.
- „Încarcă mai multe” / scroll → +20, fără duplicate.
- „Reîmprospătează” → lista rămâne pe ecran, revine la primele 20.
- Erori: F12 → Network → Offline (banner la refresh, subsol la pagină următoare).
- Progres: 10% la 400 ms, se oprește la 100%.
- Cronometru: Start / Stop / Reset, format MM:SS.

Detalii pas cu pas: `PASI.md`.

# Laborator 5 — pași de lucru

Fișierele finale sunt deja create în acest folder:

```
Laborator5/
  Perechea1/            ← catalog paginat + refresh + 3 tipuri de erori
    App.js
    screens/ProductFeedScreen.js
  Perechea2/            ← bară de progres + cronometru
    App.js
    components/ProgressBarDemo.js
    components/StopwatchDemo.js
```

Le poți copia direct într-un Snack nou (acolo creezi folderele din panoul de fișiere),
sau le poți rula local într-un proiect Expo (`npx create-expo-app`, apoi copiezi App.js în rădăcină).

Recomandare: fă laboratorul în **două Snack-uri separate** (Perechea 1 și Perechea 2), ca la curs.
Nu ai nevoie de niciun pachet extern — totul e din `react` și `react-native`.

---

## Perechea 1 — pas cu pas

### Pasul 0. Pregătește Snack-ul (2 min)
1. Deschide https://snack.expo.dev și creează un Snack nou („Create a snack”).
2. În panoul de fișiere creează folderul `screens`.
3. În `screens` creează fișierul `ProductFeedScreen.js` (gol).
4. Înlocuiește tot din `App.js` cu:
   ```js
   import ProductFeedScreen from './screens/ProductFeedScreen';

   export default function App() {
     return <ProductFeedScreen />;
   }
   ```
5. Verifică acum că nu ai erori de import (ecranul va fi gol/roșu până scrii componenta).

### Pasul 1. Prima pagină (20 min)
1. În `ProductFeedScreen.js` scrie, în ordine:
   - importurile din `react-native` (toate, inclusiv cele de care ai nevoie mai târziu);
   - constantele `PAGE_SIZE = 20`, `DELAY_MS = 1000`;
   - funcția `fetchPage(skip)` care construiește URL-ul cu `limit`, `skip`, `select` și `delay`.
2. Componenta pornește doar cu 4 state: `products`, `total`, `loading` (inițial `true`), `error`.
3. `useEffect` cu array de dependențe gol → `fetchPage(0)` → `setProducts`, `setTotal`; `catch` → `setError`; `finally` → `setLoading(false)`.
4. `if (loading)` → `ActivityIndicator` pe tot ecranul; `if (error)` → text (deocamdată).
5. `FlatList` cu `data`, `keyExtractor={(item) => String(item.id)}` și rândul cu `Image` + titlu + preț.

**Checkpoint:** după ~1 s de spinner apar 20 de produse. Dacă vezi eroare, deschide în browser
https://dummyjson.com/test — trebuie să răspundă `status: ok`.

### Pasul 2. Reîmprospătare: loading ≠ refreshing (20 min)
1. Adaugă state-ul `refreshing` (lângă `loading`).
2. Mută logica de fetch din `useEffect` într-o funcție `loadFirstPage = useCallback(async (isRefresh = false) => {...}, [])`:
   - `isRefresh ? setRefreshing(true) : setLoading(true)`;
   - `setError(null)` la început;
   - `setProducts(data.products)` — **înlocuiește** lista;
   - `finally`: oprește exact indicatorul pornit mai sus.
3. `useEffect(() => { loadFirstPage(); }, [loadFirstPage]);` — fără `useCallback` ai buclă infinită.
4. Adaugă bara de sus cu contorul `{products.length} din {total} produse` și `Pressable` „Reîmprospătează”
   (textul devine „Se reîmprospătează...” cât timp `refreshing` e `true`).
5. Pe `FlatList` adaugă:
   ```jsx
   refreshControl={
     <RefreshControl refreshing={refreshing} onRefresh={() => loadFirstPage(true)} />
   }
   ```
   Atenție: prop-ul e `refreshControl` (mic), valoarea e componenta `<RefreshControl />`.

**Checkpoint (Web):** apeși butonul → textul se schimbă, lista **rămâne** pe ecran, la final revine la primele 20.
**Checkpoint (telefon):** tragerea în jos arată indicatorul nativ. În tab-ul Web tragerea nu face nimic — e normal.

### Pasul 3. Pagina următoare (25 min)
1. Adaugă `loadingMore` și `moreError`; derivează `const hasMore = products.length < total;`.
2. Scrie `loadMore`:
   - gardă: `if (loading || refreshing || loadingMore || !hasMore) return;`
   - `const skip = products.length;`
   - `setProducts((prev) => (prev.length === skip ? [...prev, ...data.products] : prev))` — protecția anti-duplicat.
3. În `loadFirstPage`, după `setError(null)` adaugă `setMoreError(null)`.
4. Pe `FlatList`: `onEndReached`, `onEndReachedThreshold={0.5}`, `ListFooterComponent={footer}`.
   `onEndReached` cheamă `loadMore()` doar dacă `!moreError`.
5. Construiește `footer` **înainte de `return`**, cu 4 ramuri: spinner / eroare + „Reîncearcă” / buton „Încarcă mai multe” / „Ai ajuns la sfârșitul listei.”

**Checkpoint:** contorul trece 20 → 40 → 60 fără duplicate. Butonul din subsol e plasa de siguranță
dacă `onEndReached` nu se declanșează în Web.

### Pasul 4. Trei erori, trei tratamente (15 min)
1. Ecran întreg **doar** dacă nu ai date: `if (error && products.length === 0) { ... „Reîncearcă” }`.
2. Banner deasupra listei, doar când există deja date:
   `{error && <Text style={styles.banner}>Reîmprospătarea a eșuat: {error}</Text>}`
3. `moreError` rămâne exclusiv în subsol (nu ajunge niciodată la ecran întreg).
4. Confirmă garda `if (!moreError) loadMore();` — altfel o eroare de rețea se reîncearcă la nesfârșit la derulare.

**Checkpoint:** cele trei erori apar în trei locuri diferite, iar la ultimele două lista rămâne vizibilă.

### Pasul 5. Testează toate situațiile (10 min)

| Ce testezi | Cum | Ce trebuie să vezi |
|---|---|---|
| Prima încărcare | `DELAY_MS = 1000` | spinner ~1 s, apoi „20 din N” |
| Paginare | buton sau scroll la capăt | spinner în subsol, +20, fără duplicate |
| Sfârșit listă | temporar `PAGE_SIZE = 100` | „N din N” + „Ai ajuns la sfârșitul listei.” |
| Refresh | buton (Web) sau tragere (telefon) | lista rămâne, revine la prima pagină |
| Eroare pagină următoare | F12 → Network → Offline → „Încarcă mai multe” → Online → „Reîncearcă” | mesaj în subsol + listă intactă |
| Eroare refresh | Offline → „Reîmprospătează” | banner deasupra listei |
| Eroare prima încărcare | schimbă `/products?` în `/productz?` | ecran întreg „Eroare server: 404” + „Reîncearcă” |

La final **readu la valorile originale** (`/products?`, `PAGE_SIZE = 20`, `DELAY_MS = 1000` sau `0`).

---

## Perechea 2 — pas cu pas (Snack nou)

### Pregătire
1. Snack nou → folderul `components` → `ProgressBarDemo.js` și `StopwatchDemo.js`.
2. `App.js` = `ScrollView` cu `padding: 20, gap: 24`, care afișează cele două componente una sub alta.

### Sarcina A — bara de progres
1. State: `progress = 0`, `running = false`.
2. Bara: `track` (fundal, `borderRadius`, `overflow: 'hidden'`) + `fill` cu `width: `${progress}%``.
3. `useEffect` dependent de `running`: dacă rulează, `setInterval` la 400 ms care face
   `setProgress(prev => Math.min(prev + 10, 100))`; cleanup `return () => clearInterval(id)`.
4. Al doilea `useEffect` dependent de `progress`: la `>= 100` → `setRunning(false)`.
   Oprirea **nu** se pune în funcția dată lui `setProgress` (aceea trebuie să fie pură).
5. Butonul „Start” face `setProgress(0); setRunning(true);` și e `disabled={running}`.

**Checkpoint:** bara se umple din 10 în 10, procentul crește, se oprește singură la 100%.

### Sarcina B — cronometrul
1. State: `seconds = 0`, `isRunning = false`.
2. `useEffect` dependent de `isRunning`: dacă rulează, `setInterval` la 1000 ms care incrementează; cleanup obligatoriu.
3. `format(total)` → `MM:SS` cu `padStart(2, '0')`.
4. Butoane: Start → `setIsRunning(true)`; Stop → `setIsRunning(false)` (fără reset); Reset → oprește **și** `setSeconds(0)`.

**Checkpoint:** Start numără o dată pe secundă; Stop îngheață valoarea; Reset readuce la `00:00`.

---

## Greșeli frecvente (verifică-le dacă ceva nu merge)

- Ai folosit `loading` și pentru refresh → lista dispare și apare spinner pe tot ecranul. Trebuie `refreshing`.
- `RefreshControl` în loc de `refreshControl` la prop, sau ai dat un boolean în loc de componentă.
- `//` în interiorul JSX → apare ca text pe ecran. Folosește `{/* ... */}`.
- Ai uitat `return () => clearInterval(id)` → intervale „fantomă”, cronometrul aleargă de două ori mai repede.
- Ai uitat `useCallback` la `loadFirstPage` → cereri în buclă.
- Aduni cu `[...prev, ...data.products]` și la refresh → produse duplicate.
- `keyExtractor` fără `String(item.id)` → warning de chei.
- Tragi de listă în tab-ul Web și „nu se întâmplă nimic” → normal, `RefreshControl` nu are implementare pe web.

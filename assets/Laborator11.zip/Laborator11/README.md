# Laborator 11 — EAS Build (APK)

```
Perechea1/   App.js „Informații despre build” + eas.json cu profil preview (APK)
Perechea2/   + variabile EXPO_PUBLIC_*, autoIncrement, .env.example, utils/buildInfo.js
```

## Rulare local (ecranul, fără EAS)
```bash
cd Perechea1        # sau Perechea2
npm install
npx expo start
```
`eas.json` se folosește doar pentru build-ul din cloud.

## Pași (necesită cont Expo)
```bash
npx create-expo-app@latest build-info --template blank
cd build-info
npx expo install expo-constants expo-application

npm install --global eas-cli
eas login
eas whoami
eas init
eas build:configure

eas build --platform android --profile preview
```
Copiază peste proiect `App.js`, `eas.json`, `app.json` (și `.env.example` → `.env` la P2).

## De ce `--profile preview`
Fără `--profile` se folosește `production`, care produce **AAB** (neinstalabil direct).
Profilul `preview` are `android.buildType: apk`.

## Verificare
| Câmp | Expo Go | APK |
|---|---|---|
| Mediu de execuție | storeClient | standalone |
| `__DEV__` | true | false |
| ID aplicație | — | `ro.exemplu.buildinfo` |
| Versiune/cod | — | `1.0.0 (1)` |

## Diagnostice înainte de build
```bash
npx expo-doctor
npx expo export
```
Fișierele din `.gitignore` nu ajung pe EAS → „None of these files exist”.
Variabilele `EXPO_PUBLIC_*` sunt publice în binar: fără chei private.

# Laborator 8 — Locație, distanțe, hartă

```
Perechea1/   permisiune + poziție, Haversine, cafenele demo, Overpass, listă sortată
Perechea2/   + hartă (react-native-maps), sincronizare listă/hartă, urmărire poziție
```

## Dependențe
`expo-location`; pentru Perechea 2: `react-native-maps`.

## Rulare
Snack nou → foldere `screens`, `utils`, `data`, `api` (și `hooks`, `components` la P2).
Harta se testează doar pe dispozitiv; pe Web se folosește `MapPanel.web.js`.

Local:
```bash
cd Perechea1        # sau Perechea2
npm install
npx expo start
```

## Verificări numerice (Haversine)
```
distanceMeters({0,0}, {0,1})        ≈ 111195 m
distanceMeters({0,0}, {1,0})        ≈ 111195 m
Paris–Londra                        ≈ 343.6 km
formatDistance(999.6)               = "1.0 km"
```

## Distanțe demo așteptate
269 m, 291 m, 427 m, 709 m, 948 m, 1.3 km (Cafeneaua Demo Nord este prima).

## Verificare
- Refuz o dată → „încearcă din nou”; refuz definitiv → Setări.
- „Cafenele reale” cu rețeaua oprită → mesaj + date demo.
- Hartă: 6 marcaje, selecția din listă se reflectă pe hartă.
- Urmărire pornită → distanțele se actualizează, cafenelele nu se mută.

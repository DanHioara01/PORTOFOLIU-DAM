# Laborator 7 — Cameră, galerie, jurnal foto, scanner QR

```
Perechea1/   jurnal în memorie: galerie, cameră, grilă, vizualizare mărită
Perechea2/   + persistență (fișiere în Paths.document, metadate în AsyncStorage) + scanner QR
```

## Dependențe
`expo-image-picker`, `expo-file-system`, `expo-camera`, `@react-native-async-storage/async-storage`.

## Rulare
- Snack: creează `screens`, `storage` și lipește fișierele.
- Local (fiecare subfolder are deja `package.json`):
```bash
cd Perechea1        # sau Perechea2
npm install
npx expo start
```

## Ce merge unde
| Funcție | Web | Telefon (Expo Go) |
|---|---|---|
| Selector galerie | da (doar din apăsare de buton) | da |
| Cameră | nu | da |
| Copiere în folder permanent | nu (URI de sesiune) | da |
| Scanner QR | nu | da |

Pe Web, după reload legendele rămân, dar imaginile apar rupte: URI-urile browserului sunt valabile doar în sesiune.

## Verificare
- Anularea selectorului nu produce eroare (`result.canceled`).
- Refuz definitiv la cameră → buton „Deschide setările”.
- Repornire pe telefon → fotografiile și legendele reapar.
- Ștergere → dispar și intrarea, și fișierul.
- QR: text simplu fără buton; link cu buton + confirmare.

import JournalScreen from './screens/JournalScreen';

export default function App() {
  return <JournalScreen />;
}

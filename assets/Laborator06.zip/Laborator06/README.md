# Laborator 6 — Login + persistență

```
Perechea1/   login, sesiune în SecureStore, restaurare cu GET /auth/me
Perechea2/   + notițe persistente pe utilizator (AsyncStorage)
```

## Dependențe
`@react-navigation/native`, `@react-navigation/native-stack`, `react-native-screens`,
`react-native-safe-area-context`, `@react-native-async-storage/async-storage`, `expo-secure-store`.

## Rulare
Snack nou → creează folderele `api`, `storage`, `screens` → lipește fișierele.

Local, fiecare subfolder este un proiect complet:
```bash
cd Perechea1        # sau Perechea2
npm install
npx expo start
```

## Cont de test
`emilys` / `emilyspass` (DummyJSON).

## Verificare rapidă
- Login greșit → mesajul serverului, butonul revine.
- Reload → intri direct pe Profil (sesiune păstrată).
- Logout → login; după reload rămâi la login.
- Token invalid (`'abc'`) → aplicația ajunge la login, fără ecran alb.
- Notițe: adaugă 3, reload → apar; logout + alt cont → listă separată.

Pe Web, tokenul ajunge în `localStorage` (AsyncStorage), nu în SecureStore — nesecurizat, doar pentru laborator.

Detalii: `PASI.md`.

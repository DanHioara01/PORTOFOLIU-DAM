import { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { View, ActivityIndicator, StyleSheet } from 'react-native';

import { login, getMe } from './api/auth';
import { saveToken, loadToken, clearToken } from './storage/tokenStorage';
import LoginScreen from './screens/LoginScreen';
import HomeScreen from './screens/HomeScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  const [user, setUser] = useState(null);
  // ready = am terminat de verificat dacă există o sesiune salvată
  const [ready, setReady] = useState(false);

  // La pornire: dacă avem un token salvat, îl verificăm la server
  useEffect(() => {
    async function restoreSession() {
      try {
        const token = await loadToken();
        if (token) {
          setUser(await getMe(token));
        }
      } catch {
        // token expirat sau invalid: îl ștergem și rămânem la login
        await clearToken();
      } finally {
        setReady(true);
      }
    }
    restoreSession();
  }, []);

  const handleLogin = async (username, password) => {
    const data = await login(username, password); // aruncă eroare la date greșite
    await saveToken(data.accessToken);
    setUser(data);
  };

  const handleLogout = async () => {
    await clearToken();
    setUser(null);
  };

  // Cât timp verificăm sesiunea, nu știm ce ecran să arătăm
  if (!ready) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator>
        {user ? (
          <Stack.Screen name="Home" options={{ title: 'Profil' }}>
            {(props) => <HomeScreen {...props} user={user} onLogout={handleLogout} />}
          </Stack.Screen>
        ) : (
          <Stack.Screen name="Login" options={{ title: 'Autentificare' }}>
            {(props) => <LoginScreen {...props} onLogin={handleLogin} />}
          </Stack.Screen>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
});

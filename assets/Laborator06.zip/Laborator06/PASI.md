# Laborator 6 — pași de lucru

Codul complet e în două foldere:

```
Laborator6/
  Perechea1/                 ← login + sesiune păstrată (SecureStore / AsyncStorage)
    App.js
    api/auth.js
    storage/tokenStorage.js
    screens/LoginScreen.js
    screens/HomeScreen.js
  Perechea2/                 ← + notițe persistente pe utilizator
    App.js
    api/auth.js
    storage/tokenStorage.js
    storage/notesStorage.js
    screens/LoginScreen.js
    screens/HomeScreen.js
    screens/NotesScreen.js
```

## 0. Pregătirea Snack-ului

1. https://snack.expo.dev → Create a snack.
2. Creează folderele `api`, `storage`, `screens` din panoul de fișiere.
3. Importă întâi pachetele (Snack le propune la primul import):
   - `@react-navigation/native`
   - `@react-navigation/native-stack`
   - `react-native-screens`
   - `react-native-safe-area-context`
   - `@react-native-async-storage/async-storage`
   - `expo-secure-store`

   Dacă Snack nu le propune: în panoul de fișiere → `package.json` → adaugă-le în `dependencies`
   (sau folosește butonul „Add dependency”).
4. Lipește fișierele: `api/auth.js`, `storage/tokenStorage.js`, ecranele, apoi `App.js`.

> Local, cu Expo: `npx create-expo-app laborator6`, apoi
> `npx expo install @react-navigation/native @react-navigation/native-stack react-native-screens react-native-safe-area-context @react-native-async-storage/async-storage expo-secure-store`,
> după care copiezi fișierele peste cele generate.

## 1. Testează API-ul separat (înainte de interfață)

În `App.js`, temporar:

```js
useEffect(() => {
  login('emilys', 'emilyspass')
    .then((data) => console.log(Object.keys(data)))
    .catch((e) => console.log('ERR', e.message));
}, []);
```

Așteptat: `id, username, email, firstName, lastName, gender, image, accessToken, refreshToken`.
Apoi încearcă `login('emilys', 'gresit')` → mesaj de eroare de la server. Șterge testul.

## 2. LoginScreen

- `username`, `password`, `loading`, `error` — toate state-uri controlate.
- `canSubmit = username.trim() !== '' && password !== '' && !loading`.
- `setLoading(false)` **doar** în `catch`; la succes ecranul dispare din arbore.
- `autoCapitalize="none"` la ambele câmpuri, `secureTextEntry` la parolă.

## 3. Tokenul

`storage/tokenStorage.js` alege singur:
- Web → `AsyncStorage` (localStorage, **nesecurizat**, doar pentru laborator);
- Android/iOS → `SecureStore` (Keychain / Keystore).

## 4. Sesiunea în App

- `user` + `ready`.
- `useEffect` la montare: `loadToken()`; dacă există, `getMe(token)`; la eroare `clearToken()`; în `finally` `setReady(true)`.
- Cât timp `!ready` → doar `ActivityIndicator`, ca un utilizator logat să nu vadă formularul o clipă.
- `handleLogin`: `login` → `saveToken(accessToken)` → `setUser(data)`.
- `handleLogout`: `clearToken()` → `setUser(null)`.
- Navigator: dacă `user` → doar `Home`; altfel → doar `Login`. Back-ul nu poate ajunge la Home.

## 5. Notițele (Perechea 2)

- `storage/notesStorage.js`: cheie `notes:${userId}`, `JSON.stringify` / `JSON.parse`, `try/catch` la citire.
- Citire: efect pe `[user?.id]`, cu flag `cancelled` în cleanup.
- Salvare: efect pe `[notes, notesLoaded]`, cu garda `if (user && notesLoaded)`.
  Fără `notesLoaded`, la pornire s-ar scrie `[]` peste notițele salvate.
- `handleLogout` golește doar memoria (`setNotes([])`, `setNotesLoaded(false)`), nu și AsyncStorage.
- `NotesScreen` afișează „Se încarcă notițele...” cât timp `!loaded`, ca să nu mintă cu „Nu ai nicio notiță”.

## 6. Teste

| Situație | Cum | Rezultat așteptat |
|---|---|---|
| Date greșite | `emilys` / parolă greșită | mesaj sub câmpuri, butonul revine |
| Câmpuri goale | parolă goală | buton dezactivat |
| Login reușit | `emilys` / `emilyspass` | „Profil” cu nume, e-mail, imagine |
| Sesiune păstrată | reîncarcă Snack / repornește app | profil direct, fără login |
| Deconectare | „Ieșire din cont” | login; după reload rămâne login |
| Token invalid | în `restoreSession` folosește `'abc'` în loc de token | ajunge la login, fără ecran alb |
| Notițe persistente | adaugă 3, reîncarcă | cele 3 apar, cu „Se încarcă...” scurt |
| Notițe pe user | logout → alt cont | listă separată |
| Notiță goală | doar spații + Adaugă | nu se adaugă nimic |

## Greșeli frecvente

- Ai uitat `setReady(true)` în `finally` → ecran blocat pe spinner.
- Ai pus salvarea notițelor fără `notesLoaded` → prima pornire șterge notițele.
- Ai salvat tokenul în AsyncStorage și pe telefon → în laborator trece, în realitate nu e ok.
- `fetch` nu aruncă la 401: de asta `request()` verifică `response.ok`.
- Pe Web `SecureStore` nu există → fără ramura `Platform.OS === 'web'` aplicația crapă.
- Parolă cu majusculă automată → `autoCapitalize="none"`.

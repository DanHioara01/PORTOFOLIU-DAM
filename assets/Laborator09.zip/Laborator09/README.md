# Laborator 9 — Notificări locale

```
Perechea1/   remindere după un interval (TIME_INTERVAL), listă, anulare, listener
Perechea2/   + DATE și DAILY, listă salvată în AsyncStorage, reconciliere cu sistemul
```

## Dependențe
`expo-notifications`; pentru Perechea 2: `@react-native-async-storage/async-storage`.

## Rulare
Snack nou → foldere `notifications`, `screens` (+ `storage` la P2). Testarea se face **doar pe telefon**, cu Expo Go.
În Snack Web aplicația afișează un mesaj și nu programează nimic.

Local:
```bash
cd Perechea1        # sau Perechea2
npm install
npx expo start
```

## Verificare
- Permisiunea se cere la apăsarea „Programează”, nu la pornire.
- Android: canalul se creează înainte de cererea permisiunii.
- „10 s” → banner în aplicație + „Primit acum”.
- „O dată” peste 1 minut → dispare din listă după declanșare.
- „Zilnic” → rămâne în listă.
- Oră 25 / minut 70 → validare, nu se programează.
- Repornire → lista salvată este reconciliată cu notificările din sistem.

Notă: livrarea la secundă nu este garantată (Android `bestEffort`).

import { useCallback, useEffect, useState } from 'react';
import {
  View, Text, TextInput, Pressable, FlatList, Alert,
  Platform, AppState, StyleSheet,
} from 'react-native';
import * as Notifications from 'expo-notifications';

import { ensureNotificationPermission, scheduleInSeconds } from '../notifications/setup';

const isWeb = Platform.OS === 'web';

export default function RemindersScreen() {
  const [title, setTitle] = useState('');
  const [delay, setDelay] = useState('10');
  const [scheduled, setScheduled] = useState([]);
  const [lastReceived, setLastReceived] = useState(null);

  const refresh = useCallback(async () => {
    if (isWeb) return;
    const list = await Notifications.getAllScheduledNotificationsAsync();
    // cele mai apropiate în timp, primele
    list.sort((a, b) => (a.content.data?.fireAt ?? 0) - (b.content.data?.fireAt ?? 0));
    setScheduled(list);
  }, []);

  const handleSchedule = async () => {
    const text = title.trim();
    if (text === '') return;

    const seconds = Number(delay);
    if (!Number.isFinite(seconds) || seconds < 1) {
      Alert.alert('Valoare invalidă', 'Introdu un număr de secunde mai mare sau egal cu 1.');
      return;
    }

    const allowed = await ensureNotificationPermission();
    if (!allowed) {
      Alert.alert(
        'Permisiune necesară',
        'Fără permisiunea pentru notificări, reminderele nu pot fi afișate.'
      );
      return;
    }

    await scheduleInSeconds(text, Math.round(seconds));
    setTitle('');
    refresh();
  };

  const cancelOne = async (id) => {
    await Notifications.cancelScheduledNotificationAsync(id);
    refresh();
  };

  const cancelAll = async () => {
    await Notifications.cancelAllScheduledNotificationsAsync();
    refresh();
  };

  useEffect(() => {
    if (isWeb) return;
    refresh();

    // când ajunge o notificare cât timp aplicația este deschisă: o afișăm și reîmprospătăm lista
    const subscription = Notifications.addNotificationReceivedListener((notification) => {
      setLastReceived(notification.request.content.body);
      refresh();
    });

    // dacă o notificare a sunat cât timp aplicația era în fundal, lista trebuie reîmprospătată la revenire
    const appState = AppState.addEventListener('change', (state) => {
      if (state === 'active') refresh();
    });

    return () => {
      subscription.remove();
      appState.remove();
    };
  }, [refresh]);

  if (isWeb) {
    return (
      <View style={styles.center}>
        <Text style={styles.webMessage}>
          Notificările locale se testează doar pe telefon, cu Expo Go. În browser nu se programează nimic.
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Remindere</Text>

      {lastReceived && <Text style={styles.received}>Primit acum: {lastReceived}</Text>}

      <TextInput
        style={styles.input}
        placeholder="Ce să îți reamintesc?"
        value={title}
        onChangeText={setTitle}
      />

      <View style={styles.row}>
        <Text style={styles.label}>Peste (secunde)</Text>
        <TextInput
          style={[styles.input, styles.smallInput]}
          keyboardType="number-pad"
          value={delay}
          onChangeText={setDelay}
        />
      </View>

      <Pressable style={styles.buttonPrimary} onPress={handleSchedule}>
        <Text style={styles.buttonPrimaryText}>Programează</Text>
      </Pressable>

      <View style={styles.listHeader}>
        <Text style={styles.sectionTitle}>Programate ({scheduled.length})</Text>
        {scheduled.length > 0 && (
          <Pressable onPress={cancelAll}>
            <Text style={styles.danger}>Anulează toate</Text>
          </Pressable>
        )}
      </View>

      <FlatList
        data={scheduled}
        keyExtractor={(item) => item.identifier}
        contentContainerStyle={{ gap: 8, paddingBottom: 24 }}
        ListEmptyComponent={<Text style={styles.muted}>Nimic programat.</Text>}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>{item.content.body}</Text>
              <Text style={styles.muted}>
                {item.content.data?.fireAt
                  ? new Date(item.content.data.fireAt).toLocaleTimeString('ro-RO')
                  : '—'}
              </Text>
            </View>
            <Pressable onPress={() => cancelOne(item.identifier)} hitSlop={8}>
              <Text style={styles.danger}>Anulează</Text>
            </Pressable>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingTop: 56, paddingHorizontal: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },
  webMessage: { color: '#5A6B7B', textAlign: 'center' },
  title: { fontSize: 26, fontWeight: 'bold', color: '#0B1F3A', marginBottom: 12 },
  received: { color: '#1C7293', fontWeight: '600', marginBottom: 8 },
  input: {
    borderWidth: 1, borderColor: '#C9D6E0', borderRadius: 8,
    paddingHorizontal: 12, paddingVertical: 10, color: '#0B1F3A',
  },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 12 },
  label: { color: '#5A6B7B' },
  smallInput: { width: 80 },
  buttonPrimary: {
    backgroundColor: '#0B1F3A', borderRadius: 8,
    paddingVertical: 12, alignItems: 'center', marginTop: 12,
  },
  buttonPrimaryText: { color: '#fff', fontWeight: 'bold' },
  listHeader: {
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'center', marginTop: 20, marginBottom: 8,
  },
  sectionTitle: { color: '#0B1F3A', fontWeight: '600' },
  card: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: '#F4FAFD', borderRadius: 8, padding: 12,
  },
  cardTitle: { color: '#0B1F3A', fontWeight: '600' },
  muted: { color: '#5A6B7B', fontSize: 13 },
  danger: { color: '#B0392F', fontWeight: '600', fontSize: 13 },
});

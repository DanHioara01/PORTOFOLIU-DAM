import { useEffect, useState } from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { View, ActivityIndicator, StyleSheet } from 'react-native';

import { useAuth } from '../context/AuthContext';
import { loadNotes, saveNotes } from '../storage/notesStorage';
import LoginScreen from '../screens/LoginScreen';
import HomeScreen from '../screens/HomeScreen';
import NotesScreen from '../screens/NotesScreen';

const Stack = createNativeStackNavigator();

export default function RootNavigator() {
  const { user, ready, signOut } = useAuth();

  // Notițele încă stau aici în Perechea 1; în Perechea 2 ajung în NotesContext
  const [notes, setNotes] = useState([]);
  const [notesLoaded, setNotesLoaded] = useState(false);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    setNotesLoaded(false);

    loadNotes(user.id).then((list) => {
      if (!cancelled) {
        setNotes(list);
        setNotesLoaded(true);
      }
    });

    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  useEffect(() => {
    if (user && notesLoaded) {
      saveNotes(user.id, notes);
    }
  }, [notes, notesLoaded]);

  const addNote = (text) => {
    const trimmed = text.trim();
    if (!trimmed) return;
    setNotes((prev) => [{ id: String(Date.now()), text: trimmed }, ...prev]);
  };

  const deleteNote = (id) => {
    setNotes((prev) => prev.filter((note) => note.id !== id));
  };

  const handleLogout = async () => {
    await signOut();
    setNotes([]);
    setNotesLoaded(false);
  };

  if (!ready) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <Stack.Navigator>
      {user ? (
        <>
          <Stack.Screen name="Home" options={{ title: 'Profil' }}>
            {(props) => (
              <HomeScreen {...props} noteCount={notes.length} />
            )}
          </Stack.Screen>
          <Stack.Screen name="Notes" options={{ title: 'Notițe' }}>
            {(props) => (
              <NotesScreen
                {...props}
                notes={notes}
                loaded={notesLoaded}
                onAdd={addNote}
                onDelete={deleteNote}
              />
            )}
          </Stack.Screen>
        </>
      ) : (
        <Stack.Screen name="Login" options={{ title: 'Autentificare' }}>
          {(props) => <LoginScreen {...props} />}
        </Stack.Screen>
      )}
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
});

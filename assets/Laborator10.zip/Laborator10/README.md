# Laborator 10 — Context API

Pornește de la proiectul final al Laboratorului 6 (login + notițe).

```
Perechea1/   AuthContext + RootNavigator; LoginScreen/HomeScreen folosesc useAuth
Perechea2/   + NotesContext (useReducer, două contexte) + ThemeContext + regresie
```

## Dependențe
Aceleleași ca la Laboratorul 6: React Navigation (stack nativ), AsyncStorage, SecureStore.

## Rulare local
```bash
cd Perechea1        # sau Perechea2
npm install
npx expo start
```

## Structură (Perechea 2)
```
App.js                 → ThemeProvider > AuthProvider > NotesProvider > navigare
context/AuthContext.js → user, ready, signIn, signOut (useCallback + useMemo)
context/NotesContext.js→ useReducer + NotesStateContext / NotesActionsContext
context/ThemeContext.js→ light/dark, salvat în AsyncStorage
navigation/           → doar navigare
screens/               → fără props de la părinte (în afară de navigation)
```

## Verificare
Aceleași 5 teste ca la Laboratorul 6, plus:
- comutatorul de temă schimbă ecranele deschise și antetul;
- tema se păstrează după reload, fără clipire;
- `useAuth` aruncă eroare clară în afara providerului;
- ordinea providerilor: NotesProvider este în interiorul AuthProvider.

Pentru observarea re-randărilor, adaugă temporar `console.log` în HomeScreen, NotesScreen și RootNavigator.
